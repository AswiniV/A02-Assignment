A02 Assignment

*index html Page*
Home page contains NWMSU dining details

*Price html page*
this html is to caluculate orders

*Contact html page*
Here people can contact me. 

*About me*
my details
